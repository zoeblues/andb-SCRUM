
  // @ts-ignore
  import { createRoot } from "react-dom/client";
  // @ts-ignore
  import App from "C:\\Users\\User\\Desktop\\Sprint1\\src\\App.tsx";
  import "./index.css";

  createRoot(document.getElementById("root")!).render(<App />);
